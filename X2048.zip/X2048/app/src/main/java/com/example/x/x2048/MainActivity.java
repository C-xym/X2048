package com.example.x.x2048;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Layout;
import android.util.ArrayMap;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;

import com.example.x.x2048.model.Grid;
import com.example.x.x2048.view.XGridView;

import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private Grid mGrid;
    private SharedPreferences mPreferences;

    private TextView[] mBlocks = new TextView[16];

    private final ArrayMap<Integer, Integer> drawMap = new ArrayMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] viewId = new int[]{
                R.id.block_0,
                R.id.block_1,
                R.id.block_2,
                R.id.block_3,
                R.id.block_4,
                R.id.block_5,
                R.id.block_6,
                R.id.block_7,
                R.id.block_8,
                R.id.block_9,
                R.id.block_10,
                R.id.block_11,
                R.id.block_12,
                R.id.block_13,
                R.id.block_14,
                R.id.block_15
        };
        for (int i = 0; i < 16; i++) {
            mBlocks[i] = findViewById(viewId[i]);
        }

        mGrid = Grid.getInstance();
        mPreferences = getSharedPreferences("grid", MODE_PRIVATE);
        mGrid.load(mPreferences);


        drawMap.put(0, R.drawable.blank);
        drawMap.put(2, R.drawable.block_0002);
        drawMap.put(4, R.drawable.block_0004);
        drawMap.put(8, R.drawable.block_0008);
        drawMap.put(16, R.drawable.block_0016);
        drawMap.put(32, R.drawable.block_0032);
        drawMap.put(64, R.drawable.block_0064);
        drawMap.put(128, R.drawable.block_0128);
        drawMap.put(256, R.drawable.block_0256);
        drawMap.put(512, R.drawable.block_0512);
        drawMap.put(1024, R.drawable.block_1024);
        drawMap.put(2048, R.drawable.block_2048);
        drawMap.put(4096, R.drawable.block_4096);


        ((Button) findViewById(R.id.bt_restart)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGrid.reStart();
                setGrid();
            }
        });
        ((Button) findViewById(R.id.bt_back)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGrid.back();
                setGrid();
            }
        });


        final XGridView xGridView = findViewById(R.id.x_grid_view);
        xGridView.setOnFlashListener(new XGridView.OnFlashListener() {
            @Override
            public void onFlash(int direction) {
                //setGrid();
                ArrayMap<Integer, Integer> map = Grid.getInstance().getMoveList();
                Set<Integer> from = map.keySet();
                switch (direction) {
                    case Grid.MOVE_UP:
                        for (Integer c : from) {
                            int t = map.get(c);
                            int n = c / 4 - t / 4;
                            translateUp(mBlocks[t], n,mGrid.getArr()[t]);
                        }
                        break;
                    case Grid.MOVE_RIGHT:
                        for (Integer c : from) {
                            int t = map.get(c);
                            int n = t - c;
                            translateRight(mBlocks[t], n,mGrid.getArr()[t]);
                        }
                        break;
                    case Grid.MOVE_DOWN:
                        for (Integer c : from) {
                            int t = map.get(c);
                            int n = t / 4 - c / 4;
                            translateDown(mBlocks[t], n,mGrid.getArr()[t]);
                        }
                        break;
                    case Grid.MOVE_LEFT:
                        for (Integer c : from) {
                            int t = map.get(c);
                            int n = c - t;
                            translateLeft(mBlocks[t], n,mGrid.getArr()[t]);
                        }
                }

//                ArrayMap<Integer,Integer> map1=mGrid.getNewList();
//                Set<Integer> key=map1.keySet();
//                for(Integer c:key){
//                    mBlocks[c].setBackgroundResource(drawMap.get(map.get(c)));
//                }

                mBlocks[mGrid.getNewblock()].setBackgroundResource(drawMap.get(mGrid.getArr()[mGrid.getNewblock()]));
            }
        });

        setGrid();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mGrid.save(mPreferences);
    }

    void setGrid() {
        int[] arr = mGrid.getArr();
        for (int i = 0; i < 16; i++) {
            mBlocks[i].setBackgroundResource(drawMap.get(arr[i]));
        }
    }

    void translateUp(final View view, int n, final int res) {
        Animation translate = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, n
                , TranslateAnimation.RELATIVE_TO_SELF, 0);
        translate.setDuration(150);
        view.startAnimation(translate);
        translate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setBackgroundResource(drawMap.get(res));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    void translateRight(final View view, int n, final int res) {
        Animation translate = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, -n,
                TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, 0
                , TranslateAnimation.RELATIVE_TO_SELF, 0);
        translate.setDuration(150);
        view.startAnimation(translate);
        translate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setBackgroundResource(drawMap.get(res));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    void translateDown(final View view, int n, final int res) {
        Animation translate = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, -n
                , TranslateAnimation.RELATIVE_TO_SELF, 0);
        translate.setDuration(150);
        view.startAnimation(translate);
        translate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setBackgroundResource(drawMap.get(res));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    void translateLeft(final View view, int n, final int res) {
        Animation translate = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, n,
                TranslateAnimation.RELATIVE_TO_SELF, 0,
                TranslateAnimation.RELATIVE_TO_SELF, 0
                , TranslateAnimation.RELATIVE_TO_SELF, 0);
        translate.setDuration(150);
        view.startAnimation(translate);
        translate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setBackgroundResource(drawMap.get(res));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
